<?php
  // Include required files
  require_once 'config.php';
  require_once 'inc/functions.php';

  include_once 'inc/header.php';

//   echo '<pre>', print_r($_SERVER), '</pre>';
?>

    <div class="container" style="min-height: 70vh;">
        <h1>Hello, this is about page.</h1>
    </div>

<?php
include 'inc/footer.php';