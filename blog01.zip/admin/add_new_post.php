<?php
  /**
   * Include required assets
   */
  require_once '../config.php';
  require_once '../inc/functions.php';

  get_template('inc/admin_header');

  $title = $content = $published_on = $post_image = $author = "";
  if (isset($_POST['publish'])) {
    if ($_FILES['post_img']) {
      $file_name = time() .'_'. $_FILES['post_img']['name']; //name, type, tmp_name, error, size
      // $file_name = $post_image['name'];
      $target = '../img/';
      $file_tmp = $_FILES['post_img']['tmp_name'];
      $post_image = strtolower($target . $file_name);
      move_uploaded_file($file_tmp, "../img/" .$file_name);
    }

    $post_image = $file_name;
    $title = validate($_POST['title']);
    $content = validate($_POST['content']);
    $published_on = date("F j, Y");
    $author = validate($_POST['author']);

    $res = DB_Query("INSERT INTO blog01 (img, title, content, published_on, author) VALUES ('$post_image', '$title', '$content', '$published_on', '$author');");
  }

  function validate($data) {
    $data = trim($data);
    $data = stripcslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Create New Post</li>
      </ol>
      <div class="row">
        <div class="col-12">
          <h1>Add New Post</h1>

          <?php
              // echo $res ? 'Blog saved successfully' : 'Blog saving failed!';
          ?>
          <form class="form-horizontal new_post" method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label class="control-label col-sm-2" for="heading">
                <strong>Title:</strong>
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="heading" name="title" placeholder="Title">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="author_name">
                <strong>Author:</strong>
              </label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="author_name" name="author" placeholder="Author Name">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="pwd">
                <strong>Write here:</strong>
              </label>
              <div class="col-sm-10">
                <textarea name="content" class="form-control" cols="30" rows="10" placeholder="Write here..."></textarea>
              </div>
            </div>
            <div class="form-group"> 
              <div class="col-sm-offset-2 col-sm-10">
                <input type="file" name="post_img">
                <br><br>
                <div class="text-right">
                  <button type="submit" name="publish" class="btn btn-primary btn-lg">Submit</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->

<?php
get_template('inc/admin_footer');