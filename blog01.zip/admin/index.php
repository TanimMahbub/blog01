<?php
  /**
   * Include required assets
   */
  require_once '../config.php';
  require_once '../inc/functions.php';

  get_template('inc/admin_header');
  $blogs = DB_Query("SELECT * FROM blog01 ORDER BY id DESC;");
?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">All posts</li>
      </ol>
      <div class="row">
        <div class="col-md-8 offset-2">

          <?php
            while ($blog_post = mysqli_fetch_assoc($blogs)) {
          ?>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="../img/<?= $blog_post['img'];?>" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title"><?= $blog_post['title'];?></h2>
              <p class="card-text">
                <?php
                  if (strlen($blog_post['content']) > 300)
                    $blog_post['content'] = substr($blog_post['content'], 0, 350);
                  echo $blog_post['content'];
                ?>
              </p>
              <a href="../single_post.php?id=<?= $blog_post['id'] ?>" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on <?= $blog_post['published_on']?> by <a href="#"><?= $blog_post['author']?></a>
            </div>
          </div>

          <?php
            }
          ?>

          <?php
            echo $blog_post ? $blog_post : 'No post to show';
          ?>
          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <li class="page-item">
              <a class="page-link" href="#">&larr; Older</a>
            </li>
            <li class="page-item disabled">
              <a class="page-link" href="#">Newer &rarr;</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->

<?php
get_template('inc/admin_footer');