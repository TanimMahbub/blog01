<?php
/**
 * Display Errors
 */
ini_set('display_errors', 'on');

/**
 * Constants
 */
define('DB_SERVER', 'localhost');
define('DB_USER', 'datatrix');
define('DB_PASS', 'mmk@dt.dev');
define('DB_NAME', 'php01');

/**
 * Default Paths
 */
define('ROOT', __DIR__);