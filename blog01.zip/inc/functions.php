<?php

/**
 * Database Query Function
 */
function DB_Query($sql) {
    // Connecting to Database
    $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

    // SQL Query
    $result = mysqli_query($conn, $sql);

    // Closing the connection
    mysqli_close($conn);

    return $result;
}

/**
 * Get Template Part
 */
function get_template($param = null) {
    if(is_null($param))
        return;

    $param = rtrim($param, '.php');
    include_once $param.'.php';
}

/**
 * Site URL
 */
function site_url($param = null) {
    if(is_null($param)) {
        return 'http://localhost/PHP_CLASSES/08/blog01';
    } else {
        return 'http://localhost/PHP_CLASSES/08/blog01/'.$param;
    }
}

/**
 * Active Menu
 */
function active_menu($param = null) {
    if(is_null($param))
        return;

    if($_SERVER['REQUEST_URI'] == '/PHP_CLASSES/08/blog01/' . ltrim($param, '/') ) {
        echo 'active';
    }
}