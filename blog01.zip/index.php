<?php
  // Include required files
  require_once 'config.php';
  require_once 'inc/functions.php';

  get_template('inc/header');

  // echo '<pre>', print_r($_SERVER), '</pre>';
  $blogs = DB_Query("SELECT * FROM blog01 ORDER BY id DESC;");
?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8 col-md-push-4">

          <h1 class="my-4">All Posts</h1>
          
          <?php
            while ($blog_post = mysqli_fetch_assoc($blogs)) {
          ?>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="img/<?= $blog_post['img'];?>" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title"><?= $blog_post['title'];?></h2>
              <p class="card-text">
                <?php
                  if (strlen($blog_post['content']) > 300)
                    $blog_post['content'] = substr($blog_post['content'], 0, 350);
                  echo $blog_post['content'];
                ?>
              </p>
              <a href="./single_post.php?id=<?= $blog_post['id'] ?>" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on <?= $blog_post['published_on']?> by <a href="#"><?= $blog_post['author']?></a>
            </div>
          </div>

          <?php
            }
          ?>
          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <li class="page-item">
              <a class="page-link" href="#">&larr; Older</a>
            </li>
            <li class="page-item disabled">
              <a class="page-link" href="#">Newer &rarr;</a>
            </li>
          </ul>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 col-md-pull-8">

          <?php get_template('inc/sidebar'); ?>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

<?php
/**
 * Include Footer
 */
get_template('inc/footer');