<?php
  // Include required files
  require_once 'config.php';
  require_once 'inc/functions.php';

  get_template('inc/header');

  // echo '<pre>', print_r($_SERVER), '</pre>';
  if(isset($_GET['id'])) {
        $post_id = $_GET['id'];

        if(!$post_id)
            die('No post found');

    } else {
        die('No posts to display.');
    }

    $post_data = DB_Query("SELECT * FROM blog01 WHERE id=$post_id LIMIT 1;");

    $post = mysqli_fetch_assoc($post_data);
?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8 col-md-push-4">

          <h1 class="my-4">Single Post</h1>
          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="img/<?= $post['img'];?>" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title"><?= $post['title'];?></h2>
              <p class="card-text"><?= $post['content']?></p>
            </div>
            <div class="card-footer text-muted">
              Posted on <?= $post['published_on']?> 
              by <a href="#"><?= $post['author']?></a>
            </div>
          </div>
        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4 col-md-pull-8">

          <?php get_template('inc/sidebar'); ?>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

<?php
/**
 * Include Footer
 */
get_template('inc/footer');